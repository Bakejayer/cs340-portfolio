from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:43198/AAC' % (username, password))
        self.database = self.client['AAC']
        

    # Method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Method to implement the R in CRUD
    def read(self, query_kv_pairs):
        # queries database using parameters passed into the function
        data_from_query = self.database.animals.find(query_kv_pairs,{"_id":False})

        # throws exception if no documents match query parameters
        if self.database.animals.count_documents(query_kv_pairs) == 0:
            raise Exception("No data was returned with this query")

        # returns query data or MongoDB error message if no data was returned
        return data_from_query

    # Completed method for U in CRUD
    def update(self, data_kv_to_update, update_kv_pairs):

        updated_data = self.database.animals.update_many(data_kv_to_update, {"$set": update_kv_pairs})

        # checks for document's existence
        if self.database.animals.count_documents(data_kv_to_update) == 0:
            raise Exception("The requested document(s) to update does not exist")
        
        return updated_data

    # Completed method for D in CRUD
    def delete(self, delete_kv_pairs):

        if self.database.animals.count_documents(delete_kv_pairs) == 0:
            raise Exception("The requested document(s) to delete does not exist")

        deleted_data = self.database.animals.delete_many(delete_kv_pairs)

        return deleted_data
